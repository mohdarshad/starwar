
angular.module('planetApp')
    .controller('loginController',['$scope','$rootScope','LoginService','$location',function($scope,$rootScope,LoginService,$location){
        $scope.submitted = false;
        $scope.form = {};
        var page = 1;
        var userList = [];
        $scope.validateUser =  function(){
            page = 1;
            $scope.submitted = true;
            getAllUserList();

        }

        function getAllUserList(){
            $scope.incorrectLogin =  false;
            LoginService.validateUser($scope.username,page).then(function(data){
                if(data.next){
                    userList = userList.concat(data.results);
                    page++;
                    getAllUserList();
                }else{
                    userList = userList.concat(data.results);
                    var validUser = userList.filter(function(val){
                        return val.name == $scope.username && val.birth_year == $scope.password;
                    }).length == 0? false : true;

                    if(validUser){
                        $rootScope.loggedInUser = $scope.username;

                        $location.path('/planets');
                    }else{

                        $scope.incorrectLogin =  true;
                    }
                }
            },function(error){

            });
        }
    }])
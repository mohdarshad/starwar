angular.module('planetApp')
    .factory('LoginService', ['$http','$q', function($http,$q){
        return {
            validateUser: function(userName, page){
                var defer =  $q.defer();
                var apiurl = "https://swapi.co/api/people/"+"?search="+userName+"&page="+page;
                var infoPromise = $http({
                    method: 'GET',
                    url: apiurl
                }).then(function(response) {
                    /*var validUser = response.data.results.filter(function(val){
                        return val.name == userName && val.birth_year == password;

                    }).length == 0? false : true;
                    console.log("validUser"+validUser);*/
                    defer.resolve(response.data);
                }, function(error) {
                   defer.reject(error);
                });
               return defer.promise;
            }
        }

    }])

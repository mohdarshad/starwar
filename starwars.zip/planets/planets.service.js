angular.module('planetApp')
    .factory('PlanetService', ['$http','$q', function($http,$q){
        var searchCount = 0;
        return {
            getPlanetList: function(keyword, page){
                var defer =  $q.defer();

                var apiurl = "https://swapi.co/api/planets"+"?search="+keyword+"&page="+page;
                var infoPromise = $http({
                    method: 'GET',
                    url: apiurl
                }).then(function(response) {
                    defer.resolve(response.data);

                }, function errorCallback(error) {
                    defer.reject(error);
                });
                return defer.promise;
            },
            increaseSearchCount : function(){
                searchCount = searchCount+1;
            },
            searchCountSetToZero: function(){
                searchCount = 0;
            },
            getSearchCount : function(){
                return searchCount;
            }
        }

    }])

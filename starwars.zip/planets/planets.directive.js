angular.module('planetApp')
    .directive('planetDirective', function(){
        return{
            restrict: 'AEC',
            templateUrl: '../planets/planet-partial.html',
            scope: {
                data: '='
            },
            link : function(scope,elem,attr){
                var size = Math.floor(scope.data.population/100000000) < 12 ? 12 :Math.floor(scope.data.population/100000000);
                var size = size > 50 ? 50 : size;
                elem[0].style.fontSize= size+"px";
            }
        }
    })

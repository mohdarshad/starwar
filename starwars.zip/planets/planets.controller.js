/**
 * Created by Arshad on 25-07-2017.
 */
'use strict';
angular.module('planetApp')
    .controller('planetsController',['$scope','PlanetService','$rootScope','$interval',function($scope,PlanetService,$rootScope,$interval){

        $scope.previousKeyword = "";
        $scope.masterSerachResultList = [];
        $scope.resultToBeDisplayed = [];
        console.log("$rootScope"+$rootScope.loggedInUser);
        var page =  1;

        $scope.searchForPlanets =  function(){
            $scope.searcherror = false;
            PlanetService.increaseSearchCount();
            if(PlanetService.getSearchCount()<15 || $rootScope.loggedInUser =='Luke Skywalker'){
                if($scope.previousKeyword !="" && $scope.keywordsearch.indexOf($scope.previousKeyword) == 0){
                    $scope.resultToBeDisplayed = angular.copy($scope.masterSerachResultList).filter(function(val){
                        return val.name.indexOf($scope.keywordsearch)!= -1;
                    });
                }else{
                    page = 1;
                    $scope.previousKeyword = $scope.keywordsearch;
                    getPlanets($scope.keywordsearch);
                }

            }else{
                $scope.searcherror = true;
            }
        }

        function getPlanets(key){
                PlanetService.getPlanetList(key, page).then(function(data){
                if(data.next){
                    $scope.masterSerachResultList = $scope.masterSerachResultList.concat(data.results);
                    page++;
                    getPlanets(key);
                }else{
                    $scope.masterSerachResultList = $scope.masterSerachResultList.concat(data.results);
                    $scope.resultToBeDisplayed = angular.copy($scope.masterSerachResultList);
                }
            },function(error){

            })
        }

        $interval(function(){
            PlanetService.searchCountSetToZero();
            $scope.searcherror = false;
        },60000);

    }]);
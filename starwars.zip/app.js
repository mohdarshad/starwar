
var app =  angular.module('planetApp',['ui.router']);
app.config(['$stateProvider','$urlRouterProvider',function($stateProvider,$urlRouterProvider){
    $urlRouterProvider.otherwise('login');
    $stateProvider
        .state('login',{
            url : '/login',
            controller : 'loginController',
            templateUrl: '../login/login.html'
        })
        .state('planets',{
            url: '/planets',
            controller: 'planetsController',
            templateUrl: '../planets/planets.html'
        })
}]);
